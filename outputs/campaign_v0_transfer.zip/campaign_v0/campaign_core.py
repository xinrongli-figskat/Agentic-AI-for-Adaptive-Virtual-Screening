"""Feedback-batch runner that exposes only public state to controllers."""

import time

from oracle_boundary_v0.oracle_boundary import BatchOracle

from .numerical_tools import NumericalTools, POLICIES


class FixedController:
    name = "prescribed_knn_greedy"

    def choose(self, public_state, allowed_policies):
        if "knn_greedy" not in allowed_policies:
            raise ValueError("Fixed controller lost its declared tool")
        return {"policy": "knn_greedy", "reason": "Prescribed greedy kNN selection on revealed outcomes"}


class RandomController:
    name = "uniform_random_reference"

    def choose(self, public_state, allowed_policies):
        return {"policy": "uniform_random", "reason": "Prescribed label-blind random continuation"}


class SyntheticAdaptiveStub:
    """Only for dry runs; this is NOT an LLM controller."""

    name = "synthetic_adaptive_stub_not_llm"

    def choose(self, public_state, allowed_policies):
        recent = public_state["revealed"][-10:]
        fraction = sum(row["outcome"] for row in recent) / len(recent)
        policy = "knn_diverse" if fraction < 0.3 else "knn_greedy"
        return {"policy": policy, "reason": f"Synthetic feedback rule; recent hit fraction={fraction:.3f}"}


def run_synthetic_campaign(candidates, synthetic_labels, controller, *, seed, total_budget=50,
                           initialization_queries=10, batch_size=10):
    """Dry-run a full campaign schedule; current package must not load real labels."""
    oracle = BatchOracle(candidates, synthetic_labels, seed=seed, total_budget=total_budget,
                         initialization_queries=initialization_queries, batch_size=batch_size)
    tools = NumericalTools(candidates)
    trajectory = []
    first_ids = oracle.proposed_initial_ids()
    first = oracle.query_batch_tool({"compound_keys": first_ids})
    trajectory.append({"stage": "initialization", "selection": first_ids,
                       "observations": first["observations"], "cumulative_hits": sum(r["outcome"] for r in first["observations"]),
                       "selection_seconds": 0.0})
    while oracle.public_state()["remaining_budget"]:
        state = oracle.public_state()
        decision = controller.choose(state, POLICIES)
        if not isinstance(decision, dict) or decision.get("policy") not in POLICIES or not decision.get("reason"):
            raise ValueError("Controller did not provide an allowed policy and rationale")
        started = time.perf_counter()
        chosen = tools.select_batch(state, policy=decision["policy"], seed=seed,
                                    round_number=state["next_round"])
        elapsed = time.perf_counter() - started
        response = oracle.query_batch_tool({"compound_keys": chosen})
        trajectory.append({"stage": "feedback_round_" + str(response["round"]),
                           "decision": decision, "information_available": {
                               "revealed_count": len(state["revealed"]),
                               "revealed_hits": sum(r["outcome"] for r in state["revealed"]),
                               "remaining_budget": state["remaining_budget"]},
                           "selection": chosen, "observations": response["observations"],
                           "cumulative_hits": sum(r["outcome"] for r in oracle.public_state()["revealed"]),
                           "selection_seconds": elapsed})
    return {"controller": controller.name, "seed": seed, "queried_count": total_budget,
            "hits_at_budget": trajectory[-1]["cumulative_hits"],
            "hit_recovery_checkpoints": [row["cumulative_hits"] for row in trajectory],
            "feature_build_seconds": tools.feature_build_seconds,
            "selection_seconds_total": sum(row["selection_seconds"] for row in trajectory),
            "decision_seconds_total": getattr(controller, "total_decision_seconds", 0.0),
            "trajectory": trajectory}
