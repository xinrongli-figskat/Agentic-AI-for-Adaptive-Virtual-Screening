# Campaign v0: pre-freeze dry run

This package exercises the 10-initialization + four 10-query feedback schedule
with synthetic labels. It includes a random reference, a prescribed kNN-greedy
controller, a deterministic adaptive stub, and a narrow LLM policy-choice
interface. The stub and fake decision client in tests are **not GLM**. No actual
DYRK3 outcome is queried by these programs.

Run from the remote project root after extracting `campaign_v0` beside
`oracle_boundary_v0`:

```bash
source .venv/bin/activate
python -m unittest campaign_v0.test_campaign
python -m campaign_v0.smoke_public \
  --public-dir /driveA/xinrong/agentic-screening/data/campaign_public/prefreeze_20261014T145140Z_6402306a507c6fd5
```

The first command runs synthetic-label checks, including a fake LLM client
that selects different policies across rounds and verifies its input contains
only public feedback. The second reads only the public SMILES to check that
RDKit can make the declared Morgan radius-2, 2048-bit, chirality-aware bit
fingerprints for the actual 231-candidate pool. It does not load labels.

`ToolChoiceLLMController` accepts a callable receiving a public feedback
summary and returning JSON with exactly `policy` and `reason`. It does not
implement a provider connection. A later GLM adapter must use a chosen model,
log model/token/cost details, and offer no file, shell, network, or raw data
lookup tools to the campaign agent. The pre-freeze data remains **not campaign
ready** until the protocol, controller configuration, and derived sensitivity
rule are finalized and versioned.
