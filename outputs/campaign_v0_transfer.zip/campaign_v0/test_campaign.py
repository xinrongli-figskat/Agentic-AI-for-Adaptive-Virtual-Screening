"""Synthetic-only complete-budget comparison; no real DYRK3 labels."""

import unittest

from .campaign_core import FixedController, RandomController, SyntheticAdaptiveStub, run_synthetic_campaign
from .llm_controller import ToolChoiceLLMController


class CampaignTest(unittest.TestCase):
    def test_same_initialization_full_budget_and_feedback_trace(self):
        candidates = [{"compound_key": "synthetic_" + str(i).zfill(3),
                       "standardized_smiles": "C" * (i + 1)} for i in range(80)]
        labels = {row["compound_key"]: int(i % 10 == 0) for i, row in enumerate(candidates)}
        runs = [run_synthetic_campaign(candidates, labels, controller, seed=3)
                for controller in (FixedController(), RandomController(), SyntheticAdaptiveStub())]
        initial = runs[0]["trajectory"][0]["selection"]
        for run in runs:
            self.assertEqual(run["queried_count"], 50)
            self.assertEqual(len(run["trajectory"]), 5)
            self.assertEqual(run["trajectory"][0]["selection"], initial)
            self.assertEqual([len(step["selection"]) for step in run["trajectory"]], [10] * 5)
            queried = [key for step in run["trajectory"] for key in step["selection"]]
            self.assertEqual(len(queried), len(set(queried)))
            self.assertEqual(run["hits_at_budget"], sum(labels[key] for key in queried))
            self.assertEqual(run["hit_recovery_checkpoints"][-1], run["hits_at_budget"])
            for step in run["trajectory"]:
                self.assertEqual({r["compound_key"] for r in step["observations"]}, set(step["selection"]))
        self.assertEqual(runs[0]["controller"], "prescribed_knn_greedy")
        self.assertEqual(runs[1]["controller"], "uniform_random_reference")
        self.assertEqual(runs[2]["controller"], "synthetic_adaptive_stub_not_llm")

    def test_constrained_llm_client_sees_only_public_feedback_and_can_change_policy(self):
        candidates = [{"compound_key": "synthetic_" + str(i).zfill(3),
                       "standardized_smiles": "C" * (i + 1)} for i in range(80)]
        labels = {row["compound_key"]: int(i % 3 == 0) for i, row in enumerate(candidates)}
        seen = []

        def fake_client(summary):
            self.assertNotIn("private_labels", summary)
            self.assertNotIn("candidate_pool", summary)
            self.assertEqual(summary["queried_count"], 10 * len(seen) + 10)
            self.assertEqual(summary["remaining_budget"], 40 - 10 * len(seen))
            seen.append(summary)
            policy = "knn_diverse" if summary["next_round"] % 2 else "knn_greedy"
            return {"policy": policy, "reason": "Synthetic client decision from public round number"}

        controller = ToolChoiceLLMController(fake_client, model_name="fake_client_no_api")
        run = run_synthetic_campaign(candidates, labels, controller, seed=1)
        self.assertEqual(len(seen), 4)
        self.assertEqual(len(controller.decision_log), 4)
        self.assertEqual([step["decision"]["policy"] for step in run["trajectory"][1:]],
                         ["knn_diverse", "knn_greedy", "knn_diverse", "knn_greedy"])
        self.assertEqual(run["queried_count"], 50)
        self.assertEqual(run["hits_at_budget"], sum(labels[key] for step in run["trajectory"]
                                                      for key in step["selection"]))

    def test_invalid_llm_decision_is_rejected_before_query(self):
        controller = ToolChoiceLLMController(lambda _: '{"policy":"read_private","reason":"bad"}',
                                             model_name="fake_client_no_api")
        public_state = {"candidate_pool": [], "revealed": [{"compound_key": "x", "outcome": 1}],
                        "queried_count": 1, "remaining_budget": 1, "next_round": 1,
                        "next_batch_size": 1}
        with self.assertRaises(ValueError):
            controller.choose(public_state, ("knn_greedy",))


if __name__ == "__main__":
    unittest.main()
