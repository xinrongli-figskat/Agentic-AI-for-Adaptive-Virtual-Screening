# Campaign v0: pre-freeze dry run

This package exercises the 10-initialization + four 10-query feedback schedule
with synthetic labels. It includes a random reference, a prescribed kNN-greedy
controller, a deterministic adaptive stub, and a narrow LLM policy-choice
interface. The stub and fake decision client in tests are **not GLM**. No actual
DYRK3 outcome is queried by these programs.

Run from the remote project root after extracting `campaign_v0` beside
`oracle_boundary_v0`:

```bash
source .venv/bin/activate
python -m unittest campaign_v0.test_campaign
python -m campaign_v0.smoke_public \
  --public-dir /driveA/xinrong/agentic-screening/data/campaign_public/prefreeze_20261014T145140Z_6402306a507c6fd5
```

The first command runs synthetic-label checks, including a fake LLM client
that selects different policies across rounds and verifies its input contains
only public feedback. The second reads only the public SMILES to check that
RDKit can make the declared Morgan radius-2, 2048-bit, chirality-aware bit
fingerprints for the actual 231-candidate pool. It does not load labels.

`ToolChoiceLLMController` accepts a callable receiving a public feedback
summary and returning JSON with exactly `policy` and `reason`. The optional
`OfficialGLMDecisionClient` sends that summary to the official Zhipu chat API,
using `ZAI_API_KEY` from the environment; its offline tests do **not** make an
API call. To test the connection with one synthetic-feedback request only:

```bash
read -rsp 'Zhipu API key: ' ZAI_API_KEY; echo
export ZAI_API_KEY
python -m campaign_v0.probe_glm --model glm-4.7-flash
unset ZAI_API_KEY
```

The key is never printed or written by this package. The GLM adapter offers
no file, shell, retrieval, numerical, or oracle tool to the model. The
numerical selection and label query remain in the controlled Python runner.
The public state is checked for internal consistency before an API call. The
adapter requests JSON output with thinking disabled and a 256-token output
limit; this is a pre-campaign cost and validity check, not a claim of optimal
model settings.
If the API rejects a request, the probe prints only the HTTP status, numeric
business error code, an allowlisted category and any numeric Retry-After value.
An HTTP 429 alone does not show whether the cause is a rate limit, quota,
account balance or model access. Do not retry repeatedly without checking
the business code.
The pre-freeze data remains **not campaign ready** until the model access,
full protocol, controller configuration, evaluation code, and version manifest
are finalized. This package cannot launch a real-label campaign.
