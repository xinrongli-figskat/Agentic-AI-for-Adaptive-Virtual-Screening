"""Narrow official Zhipu chat-completions adapter for public campaign summaries.

Only the injected summary is sent. No file, shell, retrieval, or oracle tool is
offered to the model. This module never reads a label file or prints the API key.
"""

import json
import os
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


OFFICIAL_ENDPOINT = "https://open.bigmodel.cn/api/paas/v4/chat/completions"
SYSTEM_PROMPT = (
    "You control one batch of a retrospective compound-search prototype. "
    "The user message contains only public candidate counts and already revealed binary outcomes. "
    "Choose exactly one of the allowed numerical selection policies for the next batch. "
    "Reason only from the supplied feedback. Do not claim to know candidate scores, "
    "unknown labels, or chemical details; numerical tools will choose actual compounds. "
    "State the observed hit counts relevant to your choice in one short sentence. "
    'Return only JSON: {"policy":"allowed_policy_name","reason":"brief evidence-based reason"}.'
)

ERROR_CATEGORIES = {
    "1113": "account_payment_required",
    "1302": "account_rate_limit",
    "1305": "model_overloaded",
    "1308": "usage_limit_wait_for_reset",
    "1309": "coding_plan_expired",
    "1310": "weekly_or_monthly_limit",
    "1311": "model_not_in_subscription",
    "1313": "fair_use_restriction",
    "1314": "enterprise_plan_expired",
    "1315": "wrong_api_key_product_type",
    "1316": "five_hour_limit_and_insufficient_balance",
    "1317": "seven_day_limit_and_insufficient_balance",
    "1318": "subaccount_monthly_spending_limit",
    "1319": "subaccount_monthly_spending_limit",
    "1320": "enterprise_monthly_spending_limit",
    "1321": "enterprise_monthly_spending_limit",
}


class GLMAPIError(RuntimeError):
    def __init__(self, http_status, business_code=None, retry_after_seconds=None):
        self.http_status = http_status
        self.business_code = business_code
        self.category = ERROR_CATEGORIES.get(business_code, "unclassified_api_error")
        self.retry_after_seconds = retry_after_seconds
        super().__init__(f"GLM API HTTP {http_status}, business code {business_code or 'unavailable'}; "
                         "no new oracle query was made for this decision")

    def public_diagnostic(self):
        return {"http_status": self.http_status, "business_code": self.business_code,
                "category": self.category, "retry_after_seconds": self.retry_after_seconds}


def parse_http_error(exc):
    """Extract only allowlisted diagnostics; never echo provider text or credentials."""
    try:
        payload = json.loads(exc.read().decode("utf-8"))
        raw_code = payload.get("error", {}).get("code")
        code = str(raw_code) if str(raw_code).isdigit() else None
    except (ValueError, AttributeError, UnicodeDecodeError):
        code = None
    retry_header = exc.headers.get("Retry-After") if exc.headers else None
    retry_after = int(retry_header) if retry_header and retry_header.isdigit() else None
    return GLMAPIError(exc.code, code, retry_after)


class OfficialGLMDecisionClient:
    def __init__(self, *, model_name="glm-4.7-flash", api_key=None, timeout_seconds=60,
                 opener=urlopen):
        self.model_name = model_name
        self._api_key = api_key or os.environ.get("ZAI_API_KEY")
        if not self._api_key:
            raise ValueError("ZAI_API_KEY is not set")
        self._timeout = timeout_seconds
        self._opener = opener
        self.last_usage = None
        self.last_request_id = None

    def __call__(self, public_summary):
        if not isinstance(public_summary, dict) or "allowed_policies" not in public_summary:
            raise ValueError("Expected a public policy-choice summary")
        payload = {"model": self.model_name,
                   "messages": [{"role": "system", "content": SYSTEM_PROMPT},
                                {"role": "user", "content": json.dumps(public_summary,
                                                                         ensure_ascii=False,
                                                                         sort_keys=True)}],
                   "response_format": {"type": "json_object"},
                   "thinking": {"type": "disabled"},
                   "max_tokens": 256,
                   "stream": False}
        request = Request(OFFICIAL_ENDPOINT,
                          data=json.dumps(payload).encode("utf-8"),
                          headers={"Authorization": "Bearer " + self._api_key,
                                   "Content-Type": "application/json"},
                          method="POST")
        try:
            with self._opener(request, timeout=self._timeout) as response:
                result = json.loads(response.read().decode("utf-8"))
        except HTTPError as exc:
            raise parse_http_error(exc) from exc
        except URLError as exc:
            raise RuntimeError("GLM API connection failed; no new oracle query was made") from exc
        self.last_usage = result.get("usage")
        self.last_request_id = result.get("id")
        try:
            return result["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError) as exc:
            raise ValueError("GLM API response lacks message content") from exc
