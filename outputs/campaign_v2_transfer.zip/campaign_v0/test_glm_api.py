"""Offline contract tests; they do not contact a real GLM service."""

import json
import unittest

from .glm_api import OFFICIAL_ENDPOINT, OfficialGLMDecisionClient
from .llm_controller import ToolChoiceLLMController


class FakeHTTPResponse:
    def __enter__(self):
        return self

    def __exit__(self, *_):
        return False

    def read(self):
        return json.dumps({"id": "fake_request", "usage": {"total_tokens": 42},
                           "choices": [{"message": {"content":
                                        '{"policy":"knn_diverse","reason":"low recent recovery"}'}}]}).encode()


class GLMAdapterTest(unittest.TestCase):
    def test_only_public_summary_sent_to_official_endpoint(self):
        inspected = []

        def fake_opener(request, *, timeout):
            inspected.append((request, timeout))
            return FakeHTTPResponse()

        client = OfficialGLMDecisionClient(api_key="test_key_not_real", opener=fake_opener)
        controller = ToolChoiceLLMController(client, model_name="glm-4.7-flash")
        state = {"candidate_pool": [{"compound_key": "x", "standardized_smiles": "CC"},
                                     {"compound_key": "y", "standardized_smiles": "CCC"}],
                 "revealed": [{"compound_key": "x", "outcome": 0}], "queried_count": 1,
                 "remaining_budget": 1, "next_round": 1, "next_batch_size": 1}
        decision = controller.choose(state, ("knn_greedy", "knn_diverse", "uniform_random"))
        self.assertEqual(decision["policy"], "knn_diverse")
        request, timeout = inspected[0]
        self.assertEqual(request.full_url, OFFICIAL_ENDPOINT)
        self.assertEqual(timeout, 60)
        body = json.loads(request.data)
        sent = json.loads(body["messages"][1]["content"])
        self.assertEqual(sent["recent_observations"], [{"compound_key": "x", "outcome": 0}])
        self.assertNotIn("candidate_pool", sent)
        self.assertNotIn("private_labels", sent)
        self.assertEqual(body["response_format"], {"type": "json_object"})
        self.assertEqual(body["thinking"], {"type": "disabled"})
        self.assertEqual(body["max_tokens"], 256)
        self.assertEqual(controller.decision_log[0]["api_usage"], {"total_tokens": 42})


if __name__ == "__main__":
    unittest.main()
