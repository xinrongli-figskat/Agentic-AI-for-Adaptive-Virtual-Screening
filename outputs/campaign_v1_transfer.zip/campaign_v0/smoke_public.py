"""Check feature construction using only the public pre-freeze candidate list."""

import argparse
import json
from pathlib import Path

from .numerical_tools import NumericalTools


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--public-dir", type=Path, required=True)
    args = parser.parse_args()
    candidates = [json.loads(line) for line in (args.public_dir / "candidates.jsonl").read_text(
        encoding="utf-8").splitlines() if line]
    tools = NumericalTools(candidates)
    print(json.dumps({"public_only": True, "labels_loaded": False,
                      "candidate_count": len(candidates),
                      "feature_count": len(tools.fingerprints),
                      "feature_build_seconds": tools.feature_build_seconds}, indent=2))


if __name__ == "__main__":
    main()
